Assignment 2 - Short Stack: Basic Two-tier Web Application using HTML/CSS/JS and Node.js  
===

Due: September 16th, by 11:59 PM.

Nicole Cotto
https://glitch.com/~a2-nicolecotto

## Your Web Application Title: To-Do List
I attempted to create an application that a user can create a to-do list. I was able to collect 3 points of data and have them show up on the console. I did struggle on making them a result on the webpage. 

I was able to use CSS to design the application. I have deisgned all the buttons and color coded tehm to be able to tell them apart. I created borders on my table and set a different font for my header.

## Technical Achievements
- **Tech Achievement 1**: All of the information is currently on one webpage

### Design/Evaluation Achievements
- **Design Achievement 1**: 
